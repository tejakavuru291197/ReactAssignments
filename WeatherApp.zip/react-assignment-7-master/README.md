# React Weather App

How to run:
1. Go to the root folder.
2. npm install, then npm start
